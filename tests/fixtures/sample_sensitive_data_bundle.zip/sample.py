"""Demo config containing fake secrets for secret-scanner testing only."""
CONFIG = {
    "SECRET_KEY": "FAKE_python_config_secret_123",
    "DB_PASSWORD": "FAKE_db_password_456",
    "API_TOKEN": "FAKE_api_token_not_real",
    "AWS_SECRET_ACCESS_KEY": "FAKE_aws_secret_not_real",
}

def main():
    print("Sample configuration loaded (fake credentials only).")

if __name__ == "__main__":
    main()
