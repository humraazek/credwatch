// SAMPLE ONLY — fake credentials for secret-scanner testing
const config = {
  secretKey: "FAKE_js_secret_key_123",
  databasePassword: "FAKE_db_password_456",
  apiToken: "FAKE_api_token_not_real",
  serviceAccountKey: "FAKE_service_account_key_not_real"
};

console.log("Demo configuration loaded; do not use these values in production.");
